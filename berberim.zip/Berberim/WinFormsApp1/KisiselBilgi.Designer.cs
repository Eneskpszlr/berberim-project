﻿namespace Berberim
{
    partial class KisiselBilgi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KisiselBilgi));
            label8 = new Label();
            panel1 = new Panel();
            pictureBoxBack = new PictureBox();
            label1 = new Label();
            panel2 = new Panel();
            textBoxSifr = new TextBox();
            textBoxTc = new TextBox();
            textBoxSoyisim = new TextBox();
            textBoxIsim = new TextBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            pswrdbtn8 = new Button();
            pswrdbtn9 = new Button();
            pictureBox1 = new PictureBox();
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxBack).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Bookman Old Style", 40.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label8.ForeColor = Color.DarkBlue;
            label8.Location = new Point(12, 30);
            label8.Name = "label8";
            label8.Size = new Size(346, 78);
            label8.TabIndex = 11;
            label8.Text = "berberim";
            // 
            // panel1
            // 
            panel1.Controls.Add(pictureBoxBack);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(23, 111);
            panel1.Name = "panel1";
            panel1.Size = new Size(529, 104);
            panel1.TabIndex = 12;
            // 
            // pictureBoxBack
            // 
            pictureBoxBack.Image = (Image)resources.GetObject("pictureBoxBack.Image");
            pictureBoxBack.Location = new Point(3, 28);
            pictureBoxBack.Name = "pictureBoxBack";
            pictureBoxBack.Size = new Size(69, 63);
            pictureBoxBack.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBoxBack.TabIndex = 15;
            pictureBoxBack.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Tahoma", 18F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(78, 44);
            label1.Name = "label1";
            label1.Size = new Size(265, 36);
            label1.TabIndex = 14;
            label1.Text = "Kişisel Bilgilerim";
            // 
            // panel2
            // 
            panel2.BackColor = Color.SandyBrown;
            panel2.Controls.Add(textBoxSifr);
            panel2.Controls.Add(textBoxTc);
            panel2.Controls.Add(textBoxSoyisim);
            panel2.Controls.Add(textBoxIsim);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(label4);
            panel2.Controls.Add(label3);
            panel2.Controls.Add(label2);
            panel2.Controls.Add(pswrdbtn8);
            panel2.Controls.Add(pswrdbtn9);
            panel2.Location = new Point(23, 234);
            panel2.Name = "panel2";
            panel2.Size = new Size(578, 317);
            panel2.TabIndex = 13;
            // 
            // textBoxSifr
            // 
            textBoxSifr.BackColor = SystemColors.Window;
            textBoxSifr.Font = new Font("Verdana", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            textBoxSifr.Location = new Point(262, 243);
            textBoxSifr.Multiline = true;
            textBoxSifr.Name = "textBoxSifr";
            textBoxSifr.ReadOnly = true;
            textBoxSifr.Size = new Size(225, 35);
            textBoxSifr.TabIndex = 26;
            // 
            // textBoxTc
            // 
            textBoxTc.BackColor = SystemColors.Window;
            textBoxTc.Font = new Font("Verdana", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            textBoxTc.Location = new Point(262, 179);
            textBoxTc.Multiline = true;
            textBoxTc.Name = "textBoxTc";
            textBoxTc.ReadOnly = true;
            textBoxTc.Size = new Size(267, 35);
            textBoxTc.TabIndex = 25;
            // 
            // textBoxSoyisim
            // 
            textBoxSoyisim.BackColor = SystemColors.Window;
            textBoxSoyisim.Font = new Font("Verdana", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            textBoxSoyisim.Location = new Point(262, 109);
            textBoxSoyisim.Multiline = true;
            textBoxSoyisim.Name = "textBoxSoyisim";
            textBoxSoyisim.ReadOnly = true;
            textBoxSoyisim.Size = new Size(267, 35);
            textBoxSoyisim.TabIndex = 24;
            // 
            // textBoxIsim
            // 
            textBoxIsim.BackColor = SystemColors.Window;
            textBoxIsim.Font = new Font("Verdana", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            textBoxIsim.Location = new Point(262, 42);
            textBoxIsim.Multiline = true;
            textBoxIsim.Name = "textBoxIsim";
            textBoxIsim.ReadOnly = true;
            textBoxIsim.Size = new Size(267, 35);
            textBoxIsim.TabIndex = 23;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Georgia", 16.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label5.Location = new Point(21, 246);
            label5.Name = "label5";
            label5.Size = new Size(94, 32);
            label5.TabIndex = 18;
            label5.Text = "Şifre:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Georgia", 16.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label4.Location = new Point(21, 182);
            label4.Name = "label4";
            label4.Size = new Size(217, 32);
            label4.TabIndex = 17;
            label4.Text = "TC Kimlik No:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Georgia", 16.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label3.Location = new Point(21, 45);
            label3.Name = "label3";
            label3.Size = new Size(89, 32);
            label3.TabIndex = 16;
            label3.Text = "İsim:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Georgia", 16.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label2.Location = new Point(21, 112);
            label2.Name = "label2";
            label2.Size = new Size(141, 32);
            label2.TabIndex = 15;
            label2.Text = "Soyisim:";
            // 
            // pswrdbtn8
            // 
            pswrdbtn8.BackgroundImage = (Image)resources.GetObject("pswrdbtn8.BackgroundImage");
            pswrdbtn8.BackgroundImageLayout = ImageLayout.Center;
            pswrdbtn8.Cursor = Cursors.Hand;
            pswrdbtn8.Location = new Point(484, 242);
            pswrdbtn8.Name = "pswrdbtn8";
            pswrdbtn8.Size = new Size(45, 36);
            pswrdbtn8.TabIndex = 27;
            pswrdbtn8.UseVisualStyleBackColor = true;
            pswrdbtn8.Click += pswrdbtn8_Click;
            // 
            // pswrdbtn9
            // 
            pswrdbtn9.BackgroundImage = (Image)resources.GetObject("pswrdbtn9.BackgroundImage");
            pswrdbtn9.BackgroundImageLayout = ImageLayout.Center;
            pswrdbtn9.Cursor = Cursors.Hand;
            pswrdbtn9.Location = new Point(484, 242);
            pswrdbtn9.Name = "pswrdbtn9";
            pswrdbtn9.Size = new Size(45, 36);
            pswrdbtn9.TabIndex = 28;
            pswrdbtn9.UseVisualStyleBackColor = true;
            pswrdbtn9.Click += pswrdbtn9_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(760, 30);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(78, 90);
            pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox1.TabIndex = 14;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // KisiselBilgi
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Bisque;
            ClientSize = new Size(862, 574);
            Controls.Add(pictureBox1);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Controls.Add(label8);
            FormBorderStyle = FormBorderStyle.None;
            Name = "KisiselBilgi";
            Text = "KisiselBilgi";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBoxBack).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label8;
        private Panel panel1;
        private Panel panel2;
        private Label label1;
        private PictureBox pictureBoxBack;
        private PictureBox pictureBox1;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox textBoxIsim;
        private TextBox textBoxSifr;
        private TextBox textBoxTc;
        private TextBox textBoxSoyisim;
        private Button pswrdbtn8;
        private Button pswrdbtn9;
    }
}