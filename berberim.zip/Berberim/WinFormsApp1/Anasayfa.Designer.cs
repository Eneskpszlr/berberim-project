﻿namespace Berberim
{
    partial class Anasayfa
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Anasayfa));
            panelBilgi = new Panel();
            label9 = new Label();
            pictureBox3 = new PictureBox();
            label5 = new Label();
            label2 = new Label();
            panelRandevu = new Panel();
            label7 = new Label();
            label6 = new Label();
            pictureBox1 = new PictureBox();
            label3 = new Label();
            panelAktif = new Panel();
            panelGecmis = new Panel();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            pictureBox2 = new PictureBox();
            label4 = new Label();
            label1 = new Label();
            label8 = new Label();
            pictureBox4 = new PictureBox();
            pictureBox5 = new PictureBox();
            panelBilgi.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panelRandevu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panelGecmis.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            SuspendLayout();
            // 
            // panelBilgi
            // 
            panelBilgi.BackColor = Color.Peru;
            panelBilgi.Controls.Add(label9);
            panelBilgi.Controls.Add(pictureBox3);
            panelBilgi.Controls.Add(label5);
            panelBilgi.Controls.Add(label2);
            panelBilgi.Cursor = Cursors.Hand;
            panelBilgi.Location = new Point(49, 128);
            panelBilgi.Name = "panelBilgi";
            panelBilgi.Size = new Size(365, 151);
            panelBilgi.TabIndex = 0;
            // 
            // label9
            // 
            label9.AutoEllipsis = true;
            label9.AutoSize = true;
            label9.Font = new Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label9.ForeColor = SystemColors.Window;
            label9.Location = new Point(147, 76);
            label9.Name = "label9";
            label9.Size = new Size(88, 18);
            label9.TabIndex = 9;
            label9.Text = "için tıklayınız.";
            label9.Click += label9_Click;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(21, 25);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(112, 110);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 8;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // label5
            // 
            label5.AutoEllipsis = true;
            label5.AutoSize = true;
            label5.Font = new Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label5.ForeColor = SystemColors.Window;
            label5.Location = new Point(147, 58);
            label5.Name = "label5";
            label5.Size = new Size(201, 18);
            label5.TabIndex = 0;
            label5.Text = "Kişisel bilgilerinizi görüntülemek";
            label5.Click += label5_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = SystemColors.Info;
            label2.Location = new Point(158, 25);
            label2.Name = "label2";
            label2.Size = new Size(177, 24);
            label2.TabIndex = 7;
            label2.Text = "Kişisel Bilgilerim";
            label2.Click += label2_Click;
            // 
            // panelRandevu
            // 
            panelRandevu.BackColor = Color.OrangeRed;
            panelRandevu.Controls.Add(label7);
            panelRandevu.Controls.Add(label6);
            panelRandevu.Controls.Add(pictureBox1);
            panelRandevu.Controls.Add(label3);
            panelRandevu.Cursor = Cursors.Hand;
            panelRandevu.Location = new Point(49, 302);
            panelRandevu.Name = "panelRandevu";
            panelRandevu.Size = new Size(365, 151);
            panelRandevu.TabIndex = 1;
            // 
            // label7
            // 
            label7.AutoEllipsis = true;
            label7.AutoSize = true;
            label7.Font = new Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label7.ForeColor = SystemColors.Window;
            label7.Location = new Point(147, 75);
            label7.Name = "label7";
            label7.Size = new Size(197, 18);
            label7.TabIndex = 9;
            label7.Text = "işlemleri seçmek için tıklayınız.";
            label7.Click += label7_Click;
            // 
            // label6
            // 
            label6.AutoEllipsis = true;
            label6.AutoSize = true;
            label6.Font = new Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label6.ForeColor = SystemColors.Window;
            label6.Location = new Point(148, 57);
            label6.Name = "label6";
            label6.Size = new Size(214, 18);
            label6.TabIndex = 8;
            label6.Text = "Berberinizi ve yapmak istediğiniz";
            label6.Click += label6_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Cursor = Cursors.Hand;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(21, 23);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(112, 103);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 7;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = SystemColors.Info;
            label3.Location = new Point(186, 23);
            label3.Name = "label3";
            label3.Size = new Size(126, 24);
            label3.TabIndex = 7;
            label3.Text = "Randevu Al";
            label3.Click += label3_Click;
            // 
            // panelAktif
            // 
            panelAktif.Location = new Point(501, 175);
            panelAktif.Name = "panelAktif";
            panelAktif.Size = new Size(615, 454);
            panelAktif.TabIndex = 2;
            // 
            // panelGecmis
            // 
            panelGecmis.BackColor = Color.Crimson;
            panelGecmis.Controls.Add(label13);
            panelGecmis.Controls.Add(label12);
            panelGecmis.Controls.Add(label11);
            panelGecmis.Controls.Add(pictureBox2);
            panelGecmis.Controls.Add(label4);
            panelGecmis.Cursor = Cursors.Hand;
            panelGecmis.Location = new Point(49, 478);
            panelGecmis.Name = "panelGecmis";
            panelGecmis.Size = new Size(365, 151);
            panelGecmis.TabIndex = 5;
            // 
            // label13
            // 
            label13.AutoEllipsis = true;
            label13.AutoSize = true;
            label13.Font = new Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label13.ForeColor = SystemColors.Window;
            label13.Location = new Point(150, 89);
            label13.Name = "label13";
            label13.Size = new Size(64, 18);
            label13.TabIndex = 11;
            label13.Text = "tıklayınız.";
            label13.Click += label13_Click;
            // 
            // label12
            // 
            label12.AutoEllipsis = true;
            label12.AutoSize = true;
            label12.Font = new Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label12.ForeColor = SystemColors.Window;
            label12.Location = new Point(150, 71);
            label12.Name = "label12";
            label12.Size = new Size(201, 18);
            label12.TabIndex = 10;
            label12.Text = "randevularınıza göz atmak için";
            label12.Click += label12_Click;
            // 
            // label11
            // 
            label11.AutoEllipsis = true;
            label11.AutoSize = true;
            label11.Font = new Font("Tahoma", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label11.ForeColor = SystemColors.Window;
            label11.Location = new Point(150, 53);
            label11.Name = "label11";
            label11.Size = new Size(209, 18);
            label11.TabIndex = 9;
            label11.Text = "Daha önceden almış olduğunuz";
            label11.Click += label11_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(21, 20);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(112, 108);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 8;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Tahoma", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = SystemColors.Info;
            label4.Location = new Point(148, 20);
            label4.Name = "label4";
            label4.Size = new Size(206, 22);
            label4.TabIndex = 7;
            label4.Text = "Geçmiş Randevularım";
            label4.Click += label4_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Tahoma", 19.8000011F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(556, 116);
            label1.Name = "label1";
            label1.Size = new Size(345, 41);
            label1.TabIndex = 6;
            label1.Text = "Aktif Randevularım";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Bookman Old Style", 40.2F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label8.ForeColor = Color.DarkBlue;
            label8.Location = new Point(29, 21);
            label8.Name = "label8";
            label8.Size = new Size(346, 78);
            label8.TabIndex = 8;
            label8.Text = "berberim";
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(501, 104);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(58, 53);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 9;
            pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.Cursor = Cursors.Hand;
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(1164, 21);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(44, 87);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 10;
            pictureBox5.TabStop = false;
            pictureBox5.Click += pictureBox5_Click;
            // 
            // Anasayfa
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Bisque;
            ClientSize = new Size(1251, 658);
            Controls.Add(pictureBox5);
            Controls.Add(pictureBox4);
            Controls.Add(label8);
            Controls.Add(label1);
            Controls.Add(panelGecmis);
            Controls.Add(panelAktif);
            Controls.Add(panelRandevu);
            Controls.Add(panelBilgi);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Anasayfa";
            Text = "Berberim";
            Load += Anasayfa_Load;
            panelBilgi.ResumeLayout(false);
            panelBilgi.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panelRandevu.ResumeLayout(false);
            panelRandevu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panelGecmis.ResumeLayout(false);
            panelGecmis.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panelBilgi;
        private Panel panelRandevu;
        private Panel panelAktif;
        private Label label2;
        private Label label3;
        private Panel panelGecmis;
        private Label label4;
        private Label label1;
        private Label label5;
        private PictureBox pictureBox1;
        private Label label8;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private Label label9;
        private Label label7;
        private Label label6;
        private Label label13;
        private Label label12;
        private Label label11;
        private PictureBox pictureBox4;
        private PictureBox pictureBox5;
    }
}