﻿namespace Berberim
{
    partial class Randevu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Randevu));
            btnRandevuAl = new Button();
            checkBox1 = new CheckBox();
            checkBox2 = new CheckBox();
            checkBox3 = new CheckBox();
            checkBox4 = new CheckBox();
            checkBox5 = new CheckBox();
            checkBox6 = new CheckBox();
            checkBox7 = new CheckBox();
            btnOdeme = new Button();
            textToplamFiyat = new TextBox();
            label5 = new Label();
            panel2 = new Panel();
            label9 = new Label();
            pictureBox2 = new PictureBox();
            comboBoxSaat = new ComboBox();
            label4 = new Label();
            comboBoxBerber = new ComboBox();
            label3 = new Label();
            comboBoxIlce = new ComboBox();
            label2 = new Label();
            comboBoxSehir = new ComboBox();
            label1 = new Label();
            monthCalendar1 = new MonthCalendar();
            btnOdemeGec = new Button();
            label8 = new Label();
            panel1 = new Panel();
            title = new Label();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // btnRandevuAl
            // 
            btnRandevuAl.BackColor = Color.SteelBlue;
            btnRandevuAl.Cursor = Cursors.Hand;
            btnRandevuAl.Font = new Font("Microsoft PhagsPa", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            btnRandevuAl.ForeColor = SystemColors.Info;
            btnRandevuAl.Location = new Point(371, 387);
            btnRandevuAl.Margin = new Padding(3, 4, 3, 4);
            btnRandevuAl.Name = "btnRandevuAl";
            btnRandevuAl.Size = new Size(175, 75);
            btnRandevuAl.TabIndex = 12;
            btnRandevuAl.Text = "Ödemeyi tamamla";
            btnRandevuAl.UseVisualStyleBackColor = false;
            btnRandevuAl.Click += btnRandevuAl_Click;
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Font = new Font("Tahoma", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            checkBox1.Location = new Point(29, 115);
            checkBox1.Margin = new Padding(3, 4, 3, 4);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(122, 26);
            checkBox1.TabIndex = 13;
            checkBox1.Text = "Saç kesim";
            checkBox1.UseVisualStyleBackColor = true;
            checkBox1.CheckedChanged += checkBox1_CheckedChanged;
            // 
            // checkBox2
            // 
            checkBox2.AutoSize = true;
            checkBox2.Font = new Font("Tahoma", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            checkBox2.Location = new Point(455, 115);
            checkBox2.Margin = new Padding(3, 4, 3, 4);
            checkBox2.Name = "checkBox2";
            checkBox2.Size = new Size(65, 26);
            checkBox2.TabIndex = 14;
            checkBox2.Text = "Fön";
            checkBox2.UseVisualStyleBackColor = true;
            checkBox2.CheckedChanged += checkBox2_CheckedChanged;
            // 
            // checkBox3
            // 
            checkBox3.AutoSize = true;
            checkBox3.Font = new Font("Tahoma", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            checkBox3.Location = new Point(29, 275);
            checkBox3.Margin = new Padding(3, 4, 3, 4);
            checkBox3.Name = "checkBox3";
            checkBox3.Size = new Size(77, 26);
            checkBox3.TabIndex = 15;
            checkBox3.Text = "Ağda";
            checkBox3.UseVisualStyleBackColor = true;
            checkBox3.CheckedChanged += checkBox3_CheckedChanged;
            // 
            // checkBox4
            // 
            checkBox4.Anchor = AnchorStyles.None;
            checkBox4.AutoSize = true;
            checkBox4.Font = new Font("Tahoma", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            checkBox4.Location = new Point(242, 115);
            checkBox4.Margin = new Padding(3, 4, 3, 4);
            checkBox4.Name = "checkBox4";
            checkBox4.Size = new Size(140, 26);
            checkBox4.TabIndex = 16;
            checkBox4.Text = "Saç boyama";
            checkBox4.UseVisualStyleBackColor = true;
            checkBox4.CheckedChanged += checkBox4_CheckedChanged;
            // 
            // checkBox5
            // 
            checkBox5.AutoSize = true;
            checkBox5.Font = new Font("Tahoma", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            checkBox5.Location = new Point(242, 195);
            checkBox5.Margin = new Padding(3, 4, 3, 4);
            checkBox5.Name = "checkBox5";
            checkBox5.Size = new Size(134, 26);
            checkBox5.TabIndex = 17;
            checkBox5.Text = "Saç yıkama";
            checkBox5.UseVisualStyleBackColor = true;
            checkBox5.CheckedChanged += checkBox5_CheckedChanged;
            // 
            // checkBox6
            // 
            checkBox6.Anchor = AnchorStyles.None;
            checkBox6.AutoSize = true;
            checkBox6.Font = new Font("Tahoma", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            checkBox6.Location = new Point(242, 275);
            checkBox6.Margin = new Padding(3, 4, 3, 4);
            checkBox6.Name = "checkBox6";
            checkBox6.Size = new Size(125, 26);
            checkBox6.TabIndex = 18;
            checkBox6.Text = "Yüz bakım";
            checkBox6.UseVisualStyleBackColor = true;
            checkBox6.CheckedChanged += checkBox6_CheckedChanged;
            // 
            // checkBox7
            // 
            checkBox7.AutoSize = true;
            checkBox7.Font = new Font("Tahoma", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            checkBox7.Location = new Point(29, 195);
            checkBox7.Margin = new Padding(3, 4, 3, 4);
            checkBox7.Name = "checkBox7";
            checkBox7.Size = new Size(144, 26);
            checkBox7.TabIndex = 19;
            checkBox7.Text = "Sakal kesimi";
            checkBox7.UseVisualStyleBackColor = true;
            checkBox7.CheckedChanged += checkBox7_CheckedChanged;
            // 
            // btnOdeme
            // 
            btnOdeme.Anchor = AnchorStyles.None;
            btnOdeme.Location = new Point(223, 551);
            btnOdeme.Margin = new Padding(3, 4, 3, 4);
            btnOdeme.Name = "btnOdeme";
            btnOdeme.Size = new Size(191, 75);
            btnOdeme.TabIndex = 21;
            btnOdeme.Text = "Ödemeyi tamamlayın";
            btnOdeme.UseVisualStyleBackColor = true;
            // 
            // textToplamFiyat
            // 
            textToplamFiyat.Anchor = AnchorStyles.None;
            textToplamFiyat.Enabled = false;
            textToplamFiyat.Font = new Font("Tahoma", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            textToplamFiyat.Location = new Point(109, 414);
            textToplamFiyat.Margin = new Padding(3, 4, 3, 4);
            textToplamFiyat.Name = "textToplamFiyat";
            textToplamFiyat.Size = new Size(130, 35);
            textToplamFiyat.TabIndex = 22;
            textToplamFiyat.Text = "0";
            // 
            // label5
            // 
            label5.Anchor = AnchorStyles.None;
            label5.AutoSize = true;
            label5.Font = new Font("Tahoma", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(109, 376);
            label5.Name = "label5";
            label5.Size = new Size(130, 22);
            label5.TabIndex = 23;
            label5.Text = "Toplam Tutar";
            // 
            // panel2
            // 
            panel2.BackColor = Color.SandyBrown;
            panel2.Controls.Add(label9);
            panel2.Controls.Add(checkBox1);
            panel2.Controls.Add(btnOdeme);
            panel2.Controls.Add(textToplamFiyat);
            panel2.Controls.Add(label5);
            panel2.Controls.Add(checkBox3);
            panel2.Controls.Add(checkBox5);
            panel2.Controls.Add(checkBox7);
            panel2.Controls.Add(checkBox6);
            panel2.Controls.Add(btnRandevuAl);
            panel2.Controls.Add(checkBox2);
            panel2.Controls.Add(checkBox4);
            panel2.Location = new Point(37, 178);
            panel2.Margin = new Padding(3, 4, 3, 4);
            panel2.Name = "panel2";
            panel2.Size = new Size(608, 510);
            panel2.TabIndex = 25;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Tahoma", 10.8F, FontStyle.Bold, GraphicsUnit.Point);
            label9.Location = new Point(29, 45);
            label9.Name = "label9";
            label9.Size = new Size(563, 22);
            label9.TabIndex = 24;
            label9.Text = "Lütfen berberinizden almak istediğiniz hizmetleri işaretliyiniz;";
            // 
            // pictureBox2
            // 
            pictureBox2.Cursor = Cursors.Hand;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(799, 28);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(78, 90);
            pictureBox2.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox2.TabIndex = 27;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // comboBoxSaat
            // 
            comboBoxSaat.AllowDrop = true;
            comboBoxSaat.FormattingEnabled = true;
            comboBoxSaat.ItemHeight = 20;
            comboBoxSaat.Location = new Point(425, 290);
            comboBoxSaat.Margin = new Padding(3, 4, 3, 4);
            comboBoxSaat.Name = "comboBoxSaat";
            comboBoxSaat.Size = new Size(121, 28);
            comboBoxSaat.TabIndex = 3;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(458, 253);
            label4.Name = "label4";
            label4.Size = new Size(54, 21);
            label4.TabIndex = 10;
            label4.Text = "Saat:";
            // 
            // comboBoxBerber
            // 
            comboBoxBerber.FormattingEnabled = true;
            comboBoxBerber.Location = new Point(425, 149);
            comboBoxBerber.Margin = new Padding(3, 4, 3, 4);
            comboBoxBerber.Name = "comboBoxBerber";
            comboBoxBerber.Size = new Size(121, 28);
            comboBoxBerber.TabIndex = 2;
            comboBoxBerber.SelectedIndexChanged += comboBoxBerber_SelectedIndexChanged;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(449, 115);
            label3.Name = "label3";
            label3.Size = new Size(73, 21);
            label3.TabIndex = 8;
            label3.Text = "Berber:";
            // 
            // comboBoxIlce
            // 
            comboBoxIlce.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            comboBoxIlce.FormattingEnabled = true;
            comboBoxIlce.Location = new Point(242, 149);
            comboBoxIlce.Margin = new Padding(3, 4, 3, 4);
            comboBoxIlce.Name = "comboBoxIlce";
            comboBoxIlce.Size = new Size(124, 28);
            comboBoxIlce.TabIndex = 1;
            comboBoxIlce.SelectedIndexChanged += comboBoxIlce_SelectedIndexChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(277, 115);
            label2.Name = "label2";
            label2.Size = new Size(48, 21);
            label2.TabIndex = 6;
            label2.Text = "İlçe:";
            // 
            // comboBoxSehir
            // 
            comboBoxSehir.AllowDrop = true;
            comboBoxSehir.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            comboBoxSehir.FormattingEnabled = true;
            comboBoxSehir.Location = new Point(55, 149);
            comboBoxSehir.Margin = new Padding(3, 4, 3, 4);
            comboBoxSehir.Name = "comboBoxSehir";
            comboBoxSehir.Size = new Size(124, 28);
            comboBoxSehir.TabIndex = 0;
            comboBoxSehir.SelectedIndexChanged += comboBoxSehir_SelectedIndexChanged;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            label1.AutoSize = true;
            label1.Font = new Font("Tahoma", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(86, 115);
            label1.Name = "label1";
            label1.Size = new Size(60, 21);
            label1.TabIndex = 4;
            label1.Text = "Şehir:";
            // 
            // monthCalendar1
            // 
            monthCalendar1.BackColor = SystemColors.InactiveCaptionText;
            monthCalendar1.ForeColor = SystemColors.ScrollBar;
            monthCalendar1.Location = new Point(55, 253);
            monthCalendar1.MinDate = new DateTime(2023, 1, 1, 0, 0, 0, 0);
            monthCalendar1.Name = "monthCalendar1";
            monthCalendar1.ShowToday = false;
            monthCalendar1.TabIndex = 13;
            monthCalendar1.DateChanged += monthCalendar1_DateChanged;
            // 
            // btnOdemeGec
            // 
            btnOdemeGec.BackColor = Color.SteelBlue;
            btnOdemeGec.Cursor = Cursors.Hand;
            btnOdemeGec.Font = new Font("Microsoft New Tai Lue", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            btnOdemeGec.ForeColor = SystemColors.ControlLightLight;
            btnOdemeGec.Location = new Point(402, 387);
            btnOdemeGec.Name = "btnOdemeGec";
            btnOdemeGec.Size = new Size(164, 75);
            btnOdemeGec.TabIndex = 14;
            btnOdemeGec.Text = "Ödemeye Geç";
            btnOdemeGec.UseVisualStyleBackColor = false;
            btnOdemeGec.Click += btnOdemeGec_Click;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Tahoma", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label8.Location = new Point(55, 32);
            label8.Name = "label8";
            label8.Size = new Size(491, 24);
            label8.TabIndex = 17;
            label8.Text = "Almak istediğiniz randevunun bilgilerini giriniz;";
            // 
            // panel1
            // 
            panel1.BackColor = Color.SandyBrown;
            panel1.Controls.Add(label8);
            panel1.Controls.Add(btnOdemeGec);
            panel1.Controls.Add(monthCalendar1);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(comboBoxSehir);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(comboBoxIlce);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(comboBoxBerber);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(comboBoxSaat);
            panel1.Location = new Point(37, 178);
            panel1.Margin = new Padding(3, 4, 3, 4);
            panel1.Name = "panel1";
            panel1.Size = new Size(608, 510);
            panel1.TabIndex = 24;
            // 
            // title
            // 
            title.AutoSize = true;
            title.Font = new Font("Bookman Old Style", 48F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            title.ForeColor = Color.DarkBlue;
            title.Location = new Point(21, 45);
            title.Name = "title";
            title.Size = new Size(413, 93);
            title.TabIndex = 28;
            title.Text = "berberim";
            // 
            // Randevu
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Bisque;
            ClientSize = new Size(904, 736);
            Controls.Add(title);
            Controls.Add(pictureBox2);
            Controls.Add(panel2);
            Controls.Add(panel1);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(3, 4, 3, 4);
            Name = "Randevu";
            Text = "Randevu Al";
            Load += Randevu_Load;
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnRandevuAl;
        private CheckBox checkBox1;
        private CheckBox checkBox2;
        private CheckBox checkBox3;
        private CheckBox checkBox4;
        private CheckBox checkBox5;
        private CheckBox checkBox6;
        private CheckBox checkBox7;
        private Button btnOdeme;
        private TextBox textToplamFiyat;
        private Label label5;
        private Panel panel2;
        private Label label9;
        private PictureBox pictureBox2;
        private Panel panel1;
        private Label label8;
        private Button btnOdemeGec;
        private MonthCalendar monthCalendar1;
        private Label label1;
        private ComboBox comboBoxSehir;
        private Label label2;
        private ComboBox comboBoxIlce;
        private Label label3;
        private ComboBox comboBoxBerber;
        private Label label4;
        private ComboBox comboBoxSaat;
        private Label title;
    }
}

